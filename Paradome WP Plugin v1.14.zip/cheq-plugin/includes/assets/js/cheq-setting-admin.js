jQuery(document).ready(function ($) {

    let captcha_site_key = $('tr');

    if($('#cheq_suspicious_action_field').is(':checked')) {
        $(captcha_site_key[5]).removeClass('hide');
        $(captcha_site_key[6]).removeClass('hide');
    } else {
        $(captcha_site_key[5]).addClass('hide');
        $(captcha_site_key[6]).addClass('hide');
    }

    // validate action radio and input field
    $('#cheq_action_field_blockuser, #cheq_action_field_cf7key').click(function() {
        $('#cheq_redirect_url').prop('disabled', true);
        $('input#cheq_redirect_url.hide').hide();
    });
    $('#cheq_action_field_redirect_label').click(function() {
        $('#cheq_redirect_url').removeAttr('disabled');
        $('input#cheq_redirect_url.hide').show();
    });

    $('#cheq_suspicious_action_field').click(function() {
        $(captcha_site_key[5]).toggleClass('hide');
        $(captcha_site_key[6]).toggleClass('hide');
    });

    $('#show_password').click(function() {
        $(this).hide();
        $('#hide_password').show();
        $('input#cheq_secret_key').attr( 'type', 'text' );
    });
    $('#hide_password').click(function() {
        $(this).hide();
        $('#show_password').show();
        $('input#cheq_secret_key').attr( 'type', 'password' );
    });

});