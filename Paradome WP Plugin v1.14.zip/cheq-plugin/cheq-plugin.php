<?php

/**
 * Paradome Real-Time Interception
 *
 * Plugin Name:       Paradome Real-Time Interception
 * Description:       Paradome Real-Time Interception protect your site from invalid traffic.
 * Version:           1.0.121
 * Requires at least: 5.2
 * Requires PHP:      5.4
 * Author:            Cheq.ai
 * Author URI:        https://cheq.ai
 * Text Domain:       cheq
 */

if (!defined('ABSPATH')) {
    die;
}
define('cheq_plugin_VERSION', '1.0.1');
define('cheq_plugin_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('cheq_plugin_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Provide settings fields
 *
 * @package cheq_plugin
 */
class WP_cheq_plugin
{
    /**
     * Plugin constructor.
     */
    public function __construct()
    {
        add_action('send_headers', array($this, 'cheq_server_validation'), -999);
        add_action('wp_head', array($this, 'init_cheq_frontend'), -999);
        add_action('wp_body_open', array($this, 'add_noscript_tag'), -999);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_custom_scripts'), -999);
        add_action('wp_ajax_validate_cheq_response',  array($this, 'check_with_cheq'), -999);
        add_action('wp_ajax_nopriv_validate_cheq_response',  array($this, 'check_with_cheq'), -999);
        add_action('admin_init', array($this, 'load_font_awesome'));
        add_action('admin_notices', array($this, 'invalid_secret_error'));
    }

    public function load_font_awesome()
    {
        wp_enqueue_style('fontawesome', 'https://use.fontawesome.com/releases/v5.8.1/css/all.css', '', '5.8.1');
    }

    public function invalid_secret_error()
    {
        if (get_option('cheq_invalid_secret')) {
            ?>
            <div class="error notice-error is-dismissible">
                <p>Paradome Real-Time Interception: Wrong Secret Key</p>
            </div>
            <?php
        }
    }

    public function auth_with_clickcease($api_key, $client_ip, $request_url, $event_type, $tag_hash)
    {

        $domain = str_replace('http://', '', get_site_url());
        $domain = str_replace('https://', '', $domain);

        $request_params = array(
            'ApiKey'            => $api_key,
            'ClientIP'          => $client_ip,
            'RequestURL'        => $request_url,
            'ResourceType'      => 'text/html',
            'Method'            => 'GET',
            'Host'              => strtok($domain, '/'),
            'UserAgent'         => $_SERVER['HTTP_USER_AGENT'],
            'Accept'            => $_SERVER['HTTP_ACCEPT'],
            'AcceptLanguage'    => $_SERVER['HTTP_ACCEPT_LANGUAGE'],
            'AcceptEncoding'    => $_SERVER['HTTP_ACCEPT_ENCODING'],
            'HeaderNames'       => 'Host,User-Agent,Accept,Accept-Langauge,Accept-Encoding',
            'EventType'         => $event_type,
            'TagHash'           => $tag_hash,
        );


        if ($event_type == 'page_load') {
            $request_params['HeaderNames'] = 'Host,User-Agent,Accept,Accept-Langauge,Accept-Encoding,Cookie';
            $request_params['CheqCookie'] = $_COOKIE['_cheq_rti'];
            $request_params['Referer'] = $_SERVER['HTTP_REFERER'];
            $request_params['Connection'] = $_SERVER['HTTP_CONNECTION'];
        }

        $query_string = '';
        $counter = 0;
        foreach ($request_params as $key => $value) {
            if ($counter > 0) {
                $query_string .= "&";
            }
            $query_string .= $key . '=' . $value;
            $counter++;
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://obs.cheqzone.com/v1/realtime-interception',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $query_string,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded'
            ),
        ));

        $response = curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if ($event_type == "token_validation") {
            file_put_contents(__DIR__ . '/token_validation_log.txt', print_r($request_params, true), FILE_APPEND);
            file_put_contents(__DIR__ . '/token_validation_log.txt', print_r(json_decode($response), true), FILE_APPEND);
        }

        curl_close($curl);

        if ($event_type == 'token_validation') {
            if ($httpcode == 200) {
                return true;
            }

            return false;
        } else if ($event_type == 'page_load') {

            $output = json_decode($response);
            $cookie_values = explode(';', $output->setCookie);

            $cookie_name_value = explode('=', $cookie_values[0], 2);
            try {
                setcookie($cookie_name_value[0], $cookie_name_value[1], strtotime(explode('=', $cookie_values[1])[1]), explode('=', $cookie_values[3])[1]);
            } catch (Exception $e) {

            }

            //            $malicious_codes = array( 2, 3, 6, 7, 10, 11, 16, 18 );
            $suspicious_codes = array(4, 5, 13, 14, 15);
            $allowed_codes = array(17, 19, 20);
            if (in_array($output->threatTypeCode, $allowed_codes)) {
                return array(
                    "is_valid"      => true,
                    "is_captcha"    => false,
                    "output"        => $output
                );
            } else if (in_array($output->threatTypeCode, $suspicious_codes)) {
                if (get_option('cheq_suspicious_action')) {
                    return array(
                        "is_valid"      => true,
                        "is_captcha"    => true,
                        "output"        => $output
                    );
                } else {
                    return array(
                        "is_valid"      => true,
                        "is_captcha"    => false,
                        "output"        => $output
                    );
                }
            } else if ($output->isInvalid) {
                return array(
                    "is_valid"      => false,
                    "is_captcha"    => false,
                    "output"        => $output
                );
            }
        }

        return array(
            "is_valid"      => true,
            "is_captcha"    => false,
            "output"        => $output
        );
    }

    private function removeqsvar($url, $varname)
    {
        return preg_replace('/([?&])' . $varname . '=[^&]+(&|$)/', '$1', $url);
    }

    public function clickcease_server_validation()
    {

        if (isset($_GET["user_id"]) && $_GET["user_id"] == "1003") {
            return;
        }

        global $wp;

        $clickcease_api_key = get_option('cheq_auth_key', '');
        $current_page = home_url($wp->request);
        $clickcease_domain_key = get_option('cheq_account_id', '');

        $validated = $this->auth_with_clickcease($clickcease_api_key, $this->get_the_user_ip(), $current_page, 'page_load', $clickcease_domain_key);
        if (!$validated['is_valid'] || (isset($_GET["user_id"]) && ($_GET["user_id"] == "1002" || $_GET["user_id"] == "clearhtml"))) {
            if (get_option("cheq_action_field", '') == 'blockuser') {
                $this->local_log(
                    "Server",
                    'blockuser',
                    $validated['output']->version,
                    $validated['output']->isInvalid,
                    $validated['output']->threatTypeCode,
                    $validated['output']->requestId,
                    $validated['output']->riskScore,
                    $validated['output']->setCookie
                );
                $this->log_to_cheq("info", "Successfully blocked", "blockuser");
                header('Status: 403 Forbidden', true, 403);
                header('HTTP/1.0 403 Forbidden');
                exit;
            } else if (get_option("cheq_action_field", '') == 'redirect' && $_GET['cr'] != "true") {
                $this->local_log(
                    "Server",
                    'redirect',
                    $validated['output']->version,
                    $validated['output']->isInvalid,
                    $validated['output']->threatTypeCode,
                    $validated['output']->requestId,
                    $validated['output']->riskScore,
                    $validated['output']->setCookie
                );
                $redirect_target = get_option("cheq_redirect_url");
                $this->log_to_cheq("info", "Successfully redirected to " . $redirect_target, "redirect");
                if (strpos($redirect_target, "?")) {
                    header('Location: ' . $redirect_target . "&user_id=1002&cr=true");
                } else {
                    header('Location: ' . $redirect_target . "?user_id=1002&cr=true");
                }
                exit;
            }
            exit;
        } else if (($validated['is_valid'] && $validated['is_captcha'])) {
            $this->local_log(
                "Server",
                'captcha',
                $validated['output']->version,
                $validated['output']->isInvalid,
                $validated['output']->threatTypeCode,
                $validated['output']->requestId,
                $validated['output']->riskScore,
                $validated['output']->setCookie
            );
            if (!isset($_GET['user_id']) || (isset($_GET['user_id']) && $_GET['user_id'] != '1001')) {
                $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
                $full_url = $protocol . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                $redirect_to = $this->removeqsvar($full_url, 'user_id');
                if (strpos($redirect_to, '?') !== false) {
                    $redirect_to .= '&user_id=1001';
                } else {
                    $redirect_to .= '?user_id=1001';
                }
                header('Location: ' . $redirect_to);
                exit;
            }
        }
        $this->local_log(
            "Server",
            'No action',
            $validated['output']->version,
            $validated['output']->isInvalid,
            $validated['output']->threatTypeCode,
            $validated['output']->requestId,
            $validated['output']->riskScore,
            $validated['output']->setCookie
        );
    }

    public function get_the_user_ip()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            //check ip from share internet
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            //to check ip is pass from proxy
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return explode(',', apply_filters('wpb_get_ip', $ip))[0];
    }

    public function cheq_captcha()
    {
        if (isset($_POST["h-captcha-response"]) && $_POST["h-captcha-response"]) {

            $url = 'https://hcaptcha.com/siteverify';
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');

            $headers = array(
                "Content-Type: application/x-www-form-urlencoded",
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

            $data = "response=" . $_POST["h-captcha-response"] . "&secret=" . get_option('cheq_captcha_secret');

            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

            //for debug only!
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

            $resp = curl_exec($curl);
            curl_close($curl);

            $result = json_decode($resp);
            if ($result->success) {
                $current_url = $_SERVER['REQUEST_URI'];
                $new_url = str_replace("user_id=1001", "user_id=1000", $current_url);
                header('Location: ' . $new_url);
            }
        } else {
            $style_uri = plugin_dir_url(__FILE__) . 'includes/assets/css/captcha.css';
            ?>
            <link href="<?= $style_uri ?>" rel="stylesheet">
            <form method="POST">
                <h2><?php _e('Before you proceed, please complete the captcha below', 'cheq-plugin') ?></h2>
                <div class="h-captcha" data-sitekey="<?= get_option('cheq_captcha_api_key') ?>"></div>
                <button type="submit">Submit</button>
            </form>
            <script src="https://js.hcaptcha.com/1/api.js" async defer></script>
            <?php
        }
    }

    public function cheq_server_validation()
    {

        if ((isset($_GET["user_id"]) && $_GET["user_id"] == "1003") || (isset($_GET["user_id"]) && $_GET["user_id"] == "1000")) {
            $this->log_to_cheq("info", "User is valid", "no action");
            return;
        }
        if (isset($_GET["user_id"]) && $_GET["user_id"] == "1002" || isset($_GET["user_id"]) && $_GET["user_id"] == "clearhtml") {
            if (get_option("cheq_action_field", '') == 'blockuser') {
                $this->log_to_cheq("info", "Successfully blocked", "blockuser");
                header('Status: 403 Forbidden', true, 403);
                header('HTTP/1.0 403 Forbidden');
                exit;
            } else if (get_option("cheq_action_field", '') == 'redirect' && $_GET['cr'] != "true") {
                $redirect_target = get_option("cheq_redirect_url");
                $this->log_to_cheq("info", "Successfully redirected to " . $redirect_target, "redirect");
                if (strpos($redirect_target, "?")) {
                    header('Location: ' . $redirect_target . "&user_id=1002&cr=true");
                } else {
                    header('Location: ' . $redirect_target . "?user_id=1002&cr=true");
                }
                exit;
            }
        } else if (isset($_GET["user_id"]) && $_GET["user_id"] == "1001") {
            $this->log_to_cheq("info", "Successfully served captcha", "captcha");
            $this->cheq_captcha();
            exit;
        } else {
            $this->clickcease_server_validation();
        }
    }

    public function init_cheq_frontend()
    {
        $account_id = get_option('cheq_account_id');
//        $should_add_tag = get_option('cheq_add_script_tag');
//        if (!$account_id || !$should_add_tag) {
        if (!$account_id) {
            return;
        }

        ?>
        <script async src='https://ob.cheqzone.com/i/<?= $account_id ?>.js' data-ch='WP_plugin_dev_DO_NOT_DELETE' class='ct_clicktrue_20578' data-jsonp="onCheqResponse">
        </script>
        <?php

    }

    public function add_noscript_tag()
    {
        $account_id = get_option('cheq_account_id');
        if (!$account_id) {
            return;
        }
        ?>
        <noscript>
            <iframe src='https://dani.soapfighters.com/ns/<?= $account_id ?>.html?ch=""' width='0' height='0' style='display:none'></iframe>
        </noscript>
        <?php
    }

    // Validate request on Ajax
    public function check_with_cheq()
    {

        if (isset($_GET['user_id']) && $_GET['user_id'] == "1003") {
            echo json_encode(array(
                "status"    => 200,
                "message"   => "All is good"
            ));
            exit;
        }

        // Validate nonce
        if (!wp_verify_nonce($_POST["nonce"], "ajax-nonce")) {
            echo json_encode(array(
                "status"    => 400,
                "message"   => "Request could not be validated"
            ));
            exit;
        }

        // If the user has been redirected and he is currently on the
        if (strpos($_SERVER['HTTP_REFERER'], get_option("cheq_redirect_url")) !== false) {
            echo json_encode(array(
                "status"    => 403,
                "message"   => "",
            ));
            exit;
        }

        // Validate cheq hash
        if (!isset($_POST['cheq_hash']) || empty($_POST['cheq_hash'])) {
            echo json_encode(array(
                "status"    => 400,
                "error"     => "No hash",
            ));
            exit;
        }

        $message = str_replace("-----", "+", $_POST['cheq_hash']);

        $ciphering = 'AES-192-CTR';
        $options = 0;
        $iv = substr($message, 0, 16);
        $encrypted_message = substr($message, 16);
        $secret_key = get_option('cheq_secret_key', '');

        // abe7fbd35ec78758cb936506
        $decrypted_message = openssl_decrypt($encrypted_message, $ciphering, $secret_key, $options, $iv);

        $output = explode(":", $decrypted_message);

        if (count($output) < 4) {
            update_option('cheq_invalid_secret', true);

            $log_message = "[" . date("d/m/Y-H:i:s") . "]\n";
            $log_message .= $decrypted_message . "\n";
            $log_message .= "------------------------------------------------------------------------------\n";
            file_put_contents(__DIR__ . '/log.txt', $log_message, FILE_APPEND);
            exit;
        } else {
            update_option('cheq_invalid_secret', false);
        }

        $required_action = "";
        $suspicious_codes = array(4, 5, 13, 14, 15);

        // Do no block threat types 19 and 20 even if they return invalid
        if (!in_array(intval($output[2]), array(19, 20))) {

            // If the threat type is in the suspicious threat type codes, and the user chose to display captcha
            if (in_array(intval($output[2]), $suspicious_codes) && get_option('cheq_suspicious_action')) {
                $required_action = "captcha";
                // If the threat type is either 7 or 16, empty the HTML element using JavaScript
            } else if (intval($output[2]) == 7 || intval($output[2]) == 16) {
                $required_action = "clearhtml";
            }
            // If request is invalid
            else if (intval($output[1]) && in_array(intval($output[2]), array(2, 3, 6, 7, 10, 11, 16, 17, 18))) {
                if ($required_action == "") {
                    if (get_option("cheq_action_field", '') == "blockuser") {
                        $required_action = "blockuser";
                    } else if (get_option("cheq_action_field", '') == "redirect") {
                        $required_action = "redirect";
                    }
                }
            }
        }

        $this->local_log(
            "Front",
            $required_action ? $required_action : 'No action',
            $output[0],
            $output[1],
            $output[2],
            $output[3]
        );

        // Send response to Ajax
        echo json_encode(array(
            "status"    => 200,
            "message"   => array(
                "decrypted"     => $decrypted_message,
                "action"        => $required_action,
                "url"           => get_option('cheq_redirect_url', ''),
                "output"        => $output,
            ),
        ));
        exit;
    }

    public function enqueue_custom_scripts()
    {
        wp_enqueue_script('cheqFrontEnd', plugin_dir_url(__FILE__) . 'includes/assets/js/front-end.js', array('jquery'));
        wp_localize_script(
            'cheqFrontEnd',
            'ajax_obj',
            array(
                'nonce'         => wp_create_nonce('ajax-nonce'),
                'ajax_url'      => admin_url('admin-ajax.php'),
                'ajax_action'   => 'validate_cheq_response',
            )
        );
    }

    /**
     * Init Cheq Plugin.
     */
    public function init_cheq_field_setting()
    {
        // Add new admin menu options page for cheq Setting.
        add_action('admin_menu', array($this, 'create_cheq_plugin_options_page'));
        // Register Cheq Plugin settings.
        add_action('admin_init', array($this, 'register_cheq_fields_settings'));
        add_action('admin_init', array($this, 'cheq_admin_init'), 99);
        add_action('wp_enqueue_scripts', array($this, 'cheq_plugin_add_inline_style_action'));
    }

    /**
     * Admin init action with lowest execution priority
     */
    public function cheq_admin_init()
    {
        // Admin Scripts.
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    /**
     * Create the Cheq Plugin options page
     */
    public function create_cheq_plugin_options_page()
    {
        add_menu_page(
            'Cheq Plugin',
            'Cheq Plugin',
            'manage_options',
            'cheq-plugin-options',
            array($this, 'cheq_plugin_options_page_html'),
            'dashicons-menu',
            150
        );
    }

    /**
     * Validate Options of the submission form.
     */
    public function handle_options_form()
    {

        if (!isset($_POST['cheq_plugin_form']) || !wp_verify_nonce($_POST['cheq_plugin_form'], 'cheq_plugin_options_update')) {
            ?>
            <div class="error">
                <p><?php
                    _e('Sorry, your nonce was not correct. Please try again.', 'cheq-plugin');
                    ?></p>
            </div>
            <?php
        } else {
            // Handle our form data.
            $updated = 1;
            $errors = '';
            if (!empty($_POST['cheq_action_field'])) {
                if ($_POST['cheq_action_field'] == 'redirect') {
                    if (!empty($_POST['cheq_redirect_url'])) {
                        $cheq_redirect_url = esc_url_raw($_POST['cheq_redirect_url']);
                        update_option('cheq_redirect_url', $cheq_redirect_url);
                        update_option('cheq_action_field', 'redirect');
                    } else {
                        $errors .= 'You must enter a valid redirect url.<br/>';
                        $updated = 0;
                    }
                } else if ($_POST['cheq_action_field'] == 'blockuser') {
                    update_option('cheq_action_field', 'blockuser');
                }
            }
            if (!empty($_POST['cheq_suspicious_action'])) {
                $should_update = true;
                if (!empty($_POST['cheq_captcha_api_key'])) {
                    $cheq_captcha_api_key = $_POST['cheq_captcha_api_key'];
                } else {
                    $errors .= 'Please prvide hCaptcha SiteKey';
                    $updated = 0;
                }
                if (!empty($_POST['cheq_captcha_secret'])) {
                    $cheq_captcha_secret = $_POST['cheq_captcha_secret'];
                } else {
                    $errors .= 'Please provide hCaptcha sercret';
                    $updated = 0;
                }
                if ($should_update) {
                    update_option('cheq_captcha_api_key', $cheq_captcha_api_key);
                    update_option('cheq_captcha_secret', $cheq_captcha_secret);
                    update_option('cheq_suspicious_action', true);
                }
            } else {
                update_option('cheq_suspicious_action', false);
            }
            if (!empty($_POST['cheq_account_id'])) {
                $cheq_account_id = sanitize_key($_POST['cheq_account_id']);
                set_error_handler(
                    function ($severity, $message, $file, $line) {
                        throw new ErrorException($message, $severity, $severity, $file, $line);
                    }
                );
                try {
                    file_get_contents('https://ob.cheqzone.com/i/' . $cheq_account_id . '.js');
                    update_option('cheq_account_id', $cheq_account_id);
                } catch (Exception $e) {
                    $errors .= 'Please enter a valid Account ID<br/>';
                    $updated = 0;
                }
            } else {
                $errors .= 'Please enter a valid Account ID<br/>';
                $updated = 0;
            }
            if (!empty($_POST['cheq_auth_key'])) {
                $cheq_secret_key = sanitize_key($_POST['cheq_auth_key']);
                update_option('cheq_auth_key', $cheq_secret_key);
            } else {
                $errors .= 'Please enter a an Authentication Key.<br/>';
                $updated = 0;
            }
            if (!empty($_POST['cheq_secret_key'])) {
                $cheq_secret_key = sanitize_key($_POST['cheq_secret_key']);
                update_option('cheq_secret_key', $cheq_secret_key);
                update_option('cheq_invalid_secret', false);
            } else {
                $errors .= 'Please enter a valid Secret Key.<br/>';
                $updated = 0;
            }
//            if (!empty($_POST['add_script_tag'])) {
//                update_option('cheq_add_script_tag', true);
//            } else {
//                update_option('cheq_add_script_tag', false);
//            }
            if ($updated == 0) {
                ?>
                <div class="error">
                    <p>
                        <?php
                        _e('An error occured while saving your data!<br/>', 'cheq-plugin');
                        _e($errors, 'cheq-plugin');
                        ?></p>
                </div>
                <?php
            }
            if ($updated == 1) {
                ?>
                <div class="updated">
                    <p>
                        <?php
                        _e('Your settings were saved!', 'cheq-plugin');
                        ?></p>
                </div>
                <?php
            }
        }
    }

    /**
     * Create the cheq Settings options page HTML
     */
    public function cheq_plugin_options_page_html()
    {
        // check user capabilities.
        if (!current_user_can('manage_options')) {
            return;
        }
        // check if we are updating the options.
        if (isset($_POST['updated']) && 'true' === $_POST['updated']) {
            $this->handle_options_form();
        }
        ?>
        <div class="wrap">
            <h1><?php
                _e('Settings Screen', 'cheq-plugin');
                ?></h1>
            <div class='cheq-fields-settings-header'>
                <img src='<?php echo cheq_plugin_PLUGIN_URL; ?>includes/assets/img/Logo_Login.png' alt="logo" class="logo">
            </div>
            <div class="cheq-fields-settings-wrapper">
                <form method="POST">
                    <?php
                    wp_nonce_field('cheq_plugin_options_update', 'cheq_plugin_form');
                    ?>
                    <?php
                    do_settings_sections('cheq-fields-settings-group');
                    ?>
                    <?php
                    settings_fields('cheq-fields-settings-group');
                    ?>
                    <input type="hidden" name="updated" value="true" />
                    <?php
                    submit_button();
                    ?>
                </form>
            </div>
        </div>
        <?php
    }

    /*
     * Render the HTML of cheq_plugins_account_id
     */
    function cheq_plugins_account_id_render()
    {
        ?>
        <input name="cheq_account_id" type="text" class="extralarge-text code input-field" value="<?php echo get_option('cheq_account_id', ''); ?>" />
        <?php
    }

    /*
     * Render the HTML of cheq_plugins_auth_key
     */
    function cheq_plugins_auth_key_render()
    {
        ?>
        <input name="cheq_auth_key" type="text" class="extralarge-text code input-field" value="<?php echo get_option('cheq_auth_key', ''); ?>" />
        <?php
    }

    /*
     * Render the HTML of cheq_plugins_secret_key option.
     */
    function cheq_plugins_secret_key_render()
    {

        ?>
        <div class="secret_key_container">
            <input name="cheq_secret_key" id="cheq_secret_key" type="password" class="extralarge-text code input-field" value="<?php echo get_option('cheq_secret_key', ''); ?>" />
            <div class="icon_container">
                <svg id="show_password" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
                    <path d="M279.6 160.4C282.4 160.1 285.2 160 288 160C341 160 384 202.1 384 256C384 309 341 352 288 352C234.1 352 192 309 192 256C192 253.2 192.1 250.4 192.4 247.6C201.7 252.1 212.5 256 224 256C259.3 256 288 227.3 288 192C288 180.5 284.1 169.7 279.6 160.4zM480.6 112.6C527.4 156 558.7 207.1 573.5 243.7C576.8 251.6 576.8 260.4 573.5 268.3C558.7 304 527.4 355.1 480.6 399.4C433.5 443.2 368.8 480 288 480C207.2 480 142.5 443.2 95.42 399.4C48.62 355.1 17.34 304 2.461 268.3C-.8205 260.4-.8205 251.6 2.461 243.7C17.34 207.1 48.62 156 95.42 112.6C142.5 68.84 207.2 32 288 32C368.8 32 433.5 68.84 480.6 112.6V112.6zM288 112C208.5 112 144 176.5 144 256C144 335.5 208.5 400 288 400C367.5 400 432 335.5 432 256C432 176.5 367.5 112 288 112z" />
                </svg>
                <svg id="hide_password" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
                    <path d="M150.7 92.77C195 58.27 251.8 32 320 32C400.8 32 465.5 68.84 512.6 112.6C559.4 156 590.7 207.1 605.5 243.7C608.8 251.6 608.8 260.4 605.5 268.3C592.1 300.6 565.2 346.1 525.6 386.7L630.8 469.1C641.2 477.3 643.1 492.4 634.9 502.8C626.7 513.2 611.6 515.1 601.2 506.9L9.196 42.89C-1.236 34.71-3.065 19.63 5.112 9.196C13.29-1.236 28.37-3.065 38.81 5.112L150.7 92.77zM223.1 149.5L313.4 220.3C317.6 211.8 320 202.2 320 191.1C320 180.5 316.1 169.7 311.6 160.4C314.4 160.1 317.2 159.1 320 159.1C373 159.1 416 202.1 416 255.1C416 269.7 413.1 282.7 407.1 294.5L446.6 324.7C457.7 304.3 464 280.9 464 255.1C464 176.5 399.5 111.1 320 111.1C282.7 111.1 248.6 126.2 223.1 149.5zM320 480C239.2 480 174.5 443.2 127.4 399.4C80.62 355.1 49.34 304 34.46 268.3C31.18 260.4 31.18 251.6 34.46 243.7C44 220.8 60.29 191.2 83.09 161.5L177.4 235.8C176.5 242.4 176 249.1 176 255.1C176 335.5 240.5 400 320 400C338.7 400 356.6 396.4 373 389.9L446.2 447.5C409.9 467.1 367.8 480 320 480H320z" />
                </svg>
            </div>
        </div>
        <?php
    }

    /*
     * Render the HTML of cheq_plugins_secret_key option.
     */
    function cheq_plugins_add_script_tag_render()
    {

        ?>
        <div class="add_script_tag_container">
            <input name="add_script_tag" id="add_script_tag" type="checkbox" class="input-field" <?php echo get_option('cheq_add_script_tag', '') ? 'checked' : ''; ?> />
        </div>
        <?php
    }

    /*
     * Render the HTML of cheq_plugins_action_field option.
     */
    function cheq_plugins_action_field_render()
    {
        $disabled = 1;
        if (get_option('cheq_action_field') == 'redirect') {
            $disabled = 0;
        }
        ?>
        <fieldset class="cheq_action_field_set">
            <p>Select the action to be taken for an Invalid Bot Activity or Invalid Malicious Activity</p>
            <label id="cheq_action_field_redirect_label">
                <input type="radio" name="cheq_action_field" id="cheq_action_field_redirect" value="redirect" class="input-field cheq_action_field_redirect" <?php checked('redirect', get_option('cheq_action_field'), true); ?>>
                <?php _e('Redirect to a different page', 'cheq-plugin'); ?>
                <input type="text" name="cheq_redirect_url" id="cheq_redirect_url" value="<?php echo get_option('cheq_redirect_url', ''); ?>" class="extralarge-text code input-field <?php echo get_option('cheq_action_field', '') == 'redirect' ? '' : 'hide' ?>" placeholder="Enter page url to redirect invalid users. e.g. https://example.com " <?php echo (($disabled == 1) ? " disabled" : ""); ?>>
            </label>
            <label>
                <input type="radio" name="cheq_action_field" id="cheq_action_field_blockuser" value="blockuser" class="input-field" <?php checked('blockuser', get_option('cheq_action_field'), true); ?>>
                <?php _e('Block User', 'cheq-plugin'); ?>
            </label>
        </fieldset>

        <?php
    }

    function cheq_suspicious_action_field_render()
    {
        ?>
        <input type="checkbox" name="cheq_suspicious_action" id="cheq_suspicious_action_field" class="input-field" <?php echo get_option('cheq_suspicious_action') ? "checked" : ""; ?>>
        <?php _e('Captcha', 'cheq-plugin'); ?>
        <?php
    }

    function cheq_plugins_hcaptcha_site_key_render()
    {
        ?>
        <p id="hcaptcha_helper">Get your hCaptcha SiteKey <a href="https://dashboard.hcaptcha.com/" target="_blank">Here</a></p>
        <input type="text" name="cheq_captcha_api_key" id="cheq_captcha_api_key" value="<?php echo get_option('cheq_captcha_api_key', ''); ?>" class="extralarge-text code input-field" placeholder="Enter your hCaptcha SiteKey">
        <?php
    }

    function cheq_plugins_hcaptcha_secret_key_render()
    {
        ?>
        <p>Get your hCaptcha Secret Key <a href="https://dashboard.hcaptcha.com/settings" target="_blank">Here</a> </p>
        <input type="text" name="cheq_captcha_secret" id="cheq_captcha_secret" value="<?php echo get_option('cheq_captcha_secret', ''); ?>" class="extralarge-text code input-field" placeholder="Enter your hCaptcha Secret Key">
        <?php
    }

    /*
     * Register AP Settings settings
     */
    public function register_cheq_fields_settings()
    {
        add_settings_section(
            'cheq_fields_settings_section',
            __('General options', 'cheq-plugin'),
            '',
            'cheq-fields-settings-group'
        );
        add_settings_field(
            'cheq_plugins_auth_key',
            __('Authentication Key', 'cheq-plugin'),
            array($this, 'cheq_plugins_auth_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_plugins_account_id',
            __('Account ID', 'cheq-plugin'),
            array($this, 'cheq_plugins_account_id_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_plugins_secret_key',
            __('Secret Key', 'cheq-plugin'),
            array($this, 'cheq_plugins_secret_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
//        add_settings_field(
//            'cheq_plugins_add_script_tag',
//            __('Add Script Tag', 'cheq-plugin'),
//            array($this, 'cheq_plugins_add_script_tag_render'),
//            'cheq-fields-settings-group',
//            'cheq_fields_settings_section'
//        );
        add_settings_field(
            'cheq_captcha_api_key',
            __('Action', 'cheq-plugin'),
            array($this, 'cheq_plugins_action_field_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_suspicious_action_field',
            __('For Suspicious Requests', 'cheq-plugin'),
            array($this, 'cheq_suspicious_action_field_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_captcha_api_key_field',
            __('hCaptcha SiteKey', 'cheq-plugin'),
            array($this, 'cheq_plugins_hcaptcha_site_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_captcha_secret_field',
            __('hCaptcha SecretKey', 'cheq-plugin'),
            array($this, 'cheq_plugins_hcaptcha_secret_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
    }

    /**
     *
     */

    /**
     * Loading additional stylesheet.
     *
     * Loading custom stylesheet
     */
    public function cheq_plugin_add_inline_style_action()
    {
    }

    /**
     * Load Admin scripts
     */
    public function admin_enqueue_scripts($hook)
    {
        wp_enqueue_script(
            'cheq-setting-admin',
            plugins_url('/includes/assets/js/cheq-setting-admin.js', __FILE__),
            array('jquery'),
            cheq_plugin_VERSION
        );
        wp_enqueue_style('cheq-setting-style', plugins_url('/includes/assets/css/cheq-setting-style.css', __FILE__), [], cheq_plugin_VERSION);
    }

    private function log_to_cheq($level, $log_message, $action)
    {

        $log_data = new stdClass();
        $log_data->level = $level;
        $log_data->tagHash = get_option('cheq_account_id');
        $log_data->apiKey = get_option('cheq_auth_key', '');
        $log_data->message = $log_message;
        $log_data->application = "Paradome";
        $log_data->action = $action;

        $log_message = "Log to Cheq data:\n";
        $log_message .= "{\n";
        foreach ($log_data as $key => $value) {
            $log_message .= "\t\"" . $key . "\": \"" . $value . "\"\n";
        }
        $log_message .= "}\n";
        $log_message .= "------------------------------------------------------------------------------\n";
        file_put_contents(__DIR__ . '/log.txt', $log_message, FILE_APPEND);

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://rtilogger.production.cheq-platform.com/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($log_data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $log_message = "Log to Cheq:\n";
        $log_message .= "\t$response\n";
        $log_message .= "------------------------------------------------------------------------------\n";
        file_put_contents(__DIR__ . '/log.txt', $log_message, FILE_APPEND);
    }

    public function local_log($logger, $required_action, $version, $isInvalid, $threatType, $request_id, $risk_score = null, $set_cookie = null)
    {

        $clickcease_api_key = get_option('clickcease_api_key', '');
        $clickcease_domain_key = get_option('clickcease_domain_key', '');

        $log_message = "[" . date("d/m/Y-H:i:s") . "] - " . $logger . "\n";
        $log_message .= $required_action . "\n";
        $log_message .= "\tVersion: " . $version . "\n";
        $log_message .= "\tisInvalid: " . $isInvalid . "\n";
        $log_message .= "\tThreatType: " . $threatType . "\n";
        $log_message .= "\tRequestID: " . $request_id . "\n";
        if (!is_null($risk_score)) {
            $log_message .= "\tRiskScore: " . $risk_score . "\n";
        }
        if (!is_null($set_cookie)) {
            $log_message .= "\tSetCookie: " . $set_cookie . "\n";
        }

        $this->remote_log("info", $clickcease_domain_key, $clickcease_api_key, $log_message, "Paradome", $required_action);
        $log_message .= "------------------------------------------------------------------------------\n";
        file_put_contents(__DIR__ . '/log.txt', $log_message, FILE_APPEND);
    }

    private function remote_log($level, $tag_hash, $api_key, $message, $application, $action)
    {

        $data = new stdClass();
        $data->level        = $level;
        $data->tagHash      = $tag_hash;
        $data->apiKey       = $api_key;
        $data->message      = $message;
        $data->application  = $application;
        $data->action       = $action;


        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'http://rtilogger.production.cheq-platform.com/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json'
            ),
        ));

        $response = curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        $log_message = "[" . date("d/m/Y-H:i:s") . "] - Remote logger\n";
        $log_message .= "Sent:\n";
        $log_message .= "\t" . json_encode($data) . "\n";
        $log_message .= "Received:\n";
        $log_message .= "\tResponse: " . $response . "\n";
        $log_message .= "\tStatus: " . $httpcode . "\n";
        $log_message .= "------------------------------------------------------------------------------\n";
        file_put_contents(__DIR__ . '/remote_log.txt', $log_message, FILE_APPEND);

        curl_close($curl);
    }
}

$cheq_plugins = new WP_cheq_plugin();
$cheq_plugins->init_cheq_field_setting();
